using System;

namespace Model
{
   public enum DoctorType
   {
      Pulmonology,
      specialistCheckup,
      operation,
      Cardiology
   }
}