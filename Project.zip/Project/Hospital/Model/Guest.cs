using System;

namespace Model
{
   public class Guest
   {
      private String id;
   
   }
}