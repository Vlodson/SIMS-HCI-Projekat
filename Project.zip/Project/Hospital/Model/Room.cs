using System;
using System.Collections.Generic;

namespace Model
{
   public class Room
   {
      private String id;
      private List<Equipment> equipment;
      private int floor;
      private int roomNb;
      private bool occupancy;
      private String type;
   
   }
}