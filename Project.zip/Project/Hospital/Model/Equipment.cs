using System;

namespace Model
{
   public class Equipment
   {
      private String type;
      private int quantity;
   
   }
}