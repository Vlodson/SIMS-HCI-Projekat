using System;

namespace Model
{
   public enum DoctorType
   {
      None,
      Pulmonology,
      specialistCheckup,
      Cardiology,
      operation
    }
}