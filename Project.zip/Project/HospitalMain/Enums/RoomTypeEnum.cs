﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalMain.Enums
{
    public enum RoomTypeEnum
    {
        Patient_Room,
        Operation_Room,
        Storage_Room,
        Meeting_Room,
        Inoperative
    }
}
